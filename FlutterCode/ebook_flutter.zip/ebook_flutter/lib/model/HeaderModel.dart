class HeaderModel {
  String title;
  String message;
  String image1;
  String image2;
  String type;

  HeaderModel(this.title, this.message, this.image1, this.image2, this.type);
}
