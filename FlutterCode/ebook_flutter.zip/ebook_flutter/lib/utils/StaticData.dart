class BookData {
  String bookName;
  String bookImage;

  BookData({this.bookName, this.bookImage});
}

final List<BookData> bookList = [
  BookData(bookName: "Pater & the Wolf", bookImage: "Shadow3.png"),
  BookData(bookName: "Andresh Wingfather", bookImage: "Shadow1.png"),
  BookData(bookName: "The Boy with shark", bookImage: "Shadow.png"),
  BookData(bookName: "Gullivers Travelrs", bookImage: "Shadow.jpeg"),
  BookData(bookName: "Load of the Files", bookImage: "Shadow4.png"),
  BookData(bookName: "When the Doves", bookImage: "Shadow1.png"),
  BookData(bookName: "Karen Kingsbury", bookImage: "Shadow5.png"),
  BookData(bookName: "Apollo", bookImage: "Shadow6.png"),
];

final List<BookData> bookList1 = [
  BookData(bookName: "When the Doves", bookImage: "Shadow1.png"),
  BookData(bookName: "Karen Kingsbury", bookImage: "Shadow.png"),
  BookData(bookName: "Andresh Wingfather", bookImage: "Shadow5.png"),
  BookData(bookName: "The Boy with shark", bookImage: "Shadow.png"),
  BookData(bookName: "Gullivers Travelrs", bookImage: "Shadow.jpeg"),
  BookData(bookName: "Apollo", bookImage: "Shadow3.png"),
  BookData(bookName: "Pater & the Wolf", bookImage: "Shadow6.png"),
  BookData(bookName: "Load of the Files", bookImage: "Shadow4.png"),
];

final List<BookData> bookList2 = [
  BookData(bookName: "Apollo", bookImage: "Shadow3.png"),
  BookData(bookName: "Pater & the Wolf", bookImage: "Shadow5.png"),
  BookData(bookName: "Andresh Wingfather", bookImage: "Shadow1.png"),
  BookData(bookName: "Load of the Files", bookImage: "Shadow4.png"),
  BookData(bookName: "When the Doves", bookImage: "Shadow6.png"),
  BookData(bookName: "Karen Kingsbury", bookImage: "Shadow.png"),
  BookData(bookName: "The Boy with shark", bookImage: "Shadow3.png"),
  BookData(bookName: "Gullivers Travelrs", bookImage: "Shadow.jpeg"),
];

final List<BookData> bookList3 = [
  BookData(bookName: "Karen Kingsbury", bookImage: "Shadow.png"),
  BookData(bookName: "Apollo", bookImage: "Shadow4.png"),
  BookData(bookName: "Pater & the Wolf", bookImage: "Shadow3.png"),
  BookData(bookName: "Andresh Wingfather", bookImage: "Shadow1.png"),
  BookData(bookName: "The Boy with shark", bookImage: "Shadow.png"),
  BookData(bookName: "Gullivers Travelrs", bookImage: "Shadow.jpeg"),
  BookData(bookName: "Load of the Files", bookImage: "Shadow6.png"),
  BookData(bookName: "When the Doves", bookImage: "Shadow5.png"),
];
