const font = "Jost";

const title_bookStore = "Book Store";
const title_myLibrary = "My Library";
const title_search = "Search";
const title_account = "Account";
const msg_no_internet = "You are not connected to Internet";

/*Header Title and message*/
const header_newest_book_title = "Newest Books";
const header_newest_book_message = "Explore Newest Books";
const header_featured_book_title = "Featured Books";
const header_featured_book_message = "Explore Featured Books";
const header_for_you_book_title = "Books which is";
const header_for_you_book_message = "Recommended For You";
const header_like_book_title = "Books which";
const header_like_book_message = "You May Like";

const book_store = "Book Store";
const book_store_desc = "Explore Books";

const newest_books = "Newest Books";
const newest_books_desc =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";

const featured_books = "Featured Books";
const featured_books_desc =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";

const books_for_you = "Books For You";
const books_for_you_desc =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";

const you_may_like = "You May Like";
const you_may_like_desc = "Magna laboris fugiat ad Lorem sit mollit proident.";
