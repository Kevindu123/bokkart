import 'package:flutter/material.dart';
import 'package:flutterapp/app_localizations.dart';
import 'package:flutterapp/network/rest_api_call.dart';
import 'package:flutterapp/utils/Constant.dart';
import 'package:flutterapp/utils/app_widget.dart';
import 'package:nb_utils/nb_utils.dart';

import '../main.dart';

class ChangePasswordScreen extends StatefulWidget {
  static String tag = '/ChangePasswordScreen';

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  var mOldPasswordCont = TextEditingController();
  var mNewPasswordCont = TextEditingController();
  var mConfirmPasswordCont = TextEditingController();
  bool isLoading = false;
  var userName = '';

  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    userName = await getString(USER_EMAIL);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appStore.scaffoldBackground,
        appBar: appBar(context, title: keyString(context, "lbl_change_pwd")),
        body: Stack(
          children: [
            SingleChildScrollView(
              padding: EdgeInsets.only(left: 16, right: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  16.height,
                  EditText(
                    hintText: keyString(context, "hint_enter_old_pwd"),
                    isPassword: true,
                    mController: mOldPasswordCont,
                    isSecure: true,
                  ),
                  16.height,
                  EditText(
                    hintText: keyString(context, "hint_enter_new_pwd"),
                    isPassword: true,
                    mController: mNewPasswordCont,
                    isSecure: true,
                  ),
                  16.height,
                  EditText(
                    hintText: keyString(context, "hint_enter_confirm_pwd"),
                    isPassword: true,
                    mController: mConfirmPasswordCont,
                    isSecure: true,
                  ),
                  16.height,
                  Center(
                    child: AppButton(
                      value: keyString(context, "lbl_submit"),
                      onPressed: () {
                        hideKeyboard(context);
                        if (!mounted) return;
                        setState(() {
                          if (mOldPasswordCont.text.isEmpty)
                            toast(keyString(context, "lbl_old_pwd") +
                                " " +
                                keyString(context, "lbl_field_required"));
                          else if (mNewPasswordCont.text.isEmpty)
                            toast(keyString(context, "lbl_old_pwd") +
                                " " +
                                keyString(context, "lbl_field_required"));
                          else if (mConfirmPasswordCont.text.isEmpty)
                            toast(keyString(context, "lbl_old_pwd") +
                                " " +
                                keyString(context, "lbl_field_required"));
                          else if (mConfirmPasswordCont.text !=
                              mNewPasswordCont.text)
                            toast(keyString(context, "lbl_pwd_not_match"));
                          else {
                            var request = {
                              'password': mOldPasswordCont.text,
                              'new_password': mNewPasswordCont.text,
                              'username': userName
                            };
                            setState(() {
                              isLoading = true;
                            });
                            changePassword(request).then((res) {
                              setState(() {
                                isLoading = false;
                              });
                              toast(res["message"]);
                              finish(context);
                            }).catchError((error) {
                              setState(() {
                                isLoading = false;
                              });
                              toast(error.toString());
                            });
                          }
                        });
                      },
                    ),
                  )
                ],
              ),
            ),
            isLoading
                ? Container(
                    child: CircularProgressIndicator(),
                    alignment: Alignment.center,
                  )
                : SizedBox(),
          ],
        ),
      ),
    );
  }
}
